publish('Standard.m', 'pdf')
publish('Standard.m', 'html')

publish('PostProcessing.m', 'pdf')
publish('PostProcessing.m', 'html')